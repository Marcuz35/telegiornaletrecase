
// Al momento non c'è bisogno di JS dinamico
// In futuro potrai usare questo file per aggiornare le notizie in tempo reale
